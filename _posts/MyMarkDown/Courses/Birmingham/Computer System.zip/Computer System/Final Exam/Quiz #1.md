# Feedback of Quiz#1

![image-20211111160052054](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211111160052054.png)

![image-20211111160107011](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211111160107011.png)

what will be the state memory?

![image-20211111160305960](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211111160305960.png)

![image-20211111160839763](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211111160839763.png)

![image-20211111160855587](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211111160855587.png)

![image-20211111160910648](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211111160910648.png)

![image-20211111160933497](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211111160933497.png)
**Topics Covered:** Weeks 7.5, 8, 9, & 10 (Multi-threading and its Challenges (Slide#39 on-wards),

**Access Code** to attempt it: **UY#$CUTI**



### **Concurrency & Threads**

![image-20211208161254798](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211208161254798.png)

Threads have their own stack.





### Deadlock

![image-20211208201512629](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211208201512629.png)

A process is perpetually denied necessary resources: Starvation

A way to prevent deadlock is to prevent the occurrence of circular wait

The resource allocation graph is a way to determine deadlock

To avoid deadlock, there mush be a fixed number of resources to allocate



inversion 倒转

# Feedback on Quiz # 0 (Formative)

![image-20211029102033589](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211029102033589.png)

![image-20211029102042856](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211029102042856.png)

![image-20211029102052763](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211029102052763.png)

![image-20211029102104839](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211029102104839.png)

![image-20211029102117616](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211029102117616.png)

![image-20211029102126406](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211029102126406.png)

![image-20211029102134622](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211029102134622.png)

![image-20211029102144673](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211029102144673.png)

![image-20211029102256525](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211029102256525.png)

![image-20211029102311461](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211029102311461.png)

![image-20211029102319490](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211029102319490.png)

![image-20211029102327679](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211029102327679.png)

![image-20211029102337216](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211029102337216.png)

![image-20211029102451541](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211029102451541.png)

![image-20211029102458104](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211029102458104.png)

![image-20211029102504221](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211029102504221.png)

![image-20211029102511754](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211029102511754.png)

![image-20211029102519962](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211029102519962.png)
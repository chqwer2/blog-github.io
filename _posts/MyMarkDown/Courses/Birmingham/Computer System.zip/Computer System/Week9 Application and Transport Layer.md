# Application

Answer:![image-20211210001227976](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211210001227976.png)

[Week09_Additional_Questions_Solutions_I (1).pdf](file:///C:/Users/calvchen/Downloads/Week09_Additional_Questions_Solutions_I (1).pdf)

[Week09_Additional_Questions_Solutions_II (2).pdf](file:///C:/Users/calvchen/Downloads/Week09_Additional_Questions_Solutions_II (2).pdf)

[Week09_Additional_Questions_Solutions_III (2).pdf](file:///C:/Users/calvchen/Downloads/Week09_Additional_Questions_Solutions_III (2).pdf)

## Network

![image-20211207234748515](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211207234748515.png)

![image-20211207234851793](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211207234851793.png)

![image-20211207235132731](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211207235132731.png)

![image-20211207235402313](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211207235402313.png)

### Protocol

![image-20211208085314838](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211208085314838.png)

![image-20211208085331671](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211208085331671.png)

![image-20211208085457104](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211208085457104.png)

### Protocol Layers

![image-20211208085637388](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211208085637388.png)

![image-20211208085938506](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211208085938506.png)

![image-20211208090124952](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211208090124952.png)

### Message

Larger than the frame

More than one package, may out of order

Each package contains a sequence number

![image-20211208100751911](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211208100751911.png)

### Application Layer

![image-20211208111112829](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211208111112829.png)

![image-20211208111138835](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211208111138835.png)

![image-20211208111435229](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211208111435229.png)

![image-20211208111722840](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211208111722840.png)

![image-20211208112954359](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211208112954359.png)

![image-20211208113029829](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211208113029829.png)

![image-20211208113239966](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211208113239966.png)

![image-20211208113336844](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211208113336844.png)

### HTTP

Object - URL address, using TCP in port 80

![image-20211208125445587](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211208125445587.png)

![image-20211208125525390](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211208125525390.png)

![image-20211208125641280](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211208125641280.png)

![image-20211208130845905](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211208130845905.png)

![image-20211208130906110](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211208130906110.png)

### E-mail SMTP

![image-20211208131508802](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211208131508802.png)

![image-20211208131625737](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211208131625737.png)

![image-20211208131743720](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211208131743720.png)

![image-20211208131759468](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211208131759468.png)

![image-20211208132014580](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211208132014580.png)

![image-20211208132201828](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211208132201828.png)

### DNS (Domain Name System)

![image-20211208141419850](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211208141419850.png)

Local DNS server: Services and Structure

Translate IP adress, host aliasing...

![image-20211208141859456](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211208141859456.png)

![image-20211208141956558](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211208141956558.png)

![image-20211208142256847](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211208142256847.png)



Local can act as a proxy...  代理伺服器  

TTL: Timeout after some time 

![image-20211208143828396](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211208143828396.png)

![image-20211208143949862](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211208143949862.png)

![image-20211208144404518](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211208144404518.png)

###  Transport Layer

TCP & UDP

### Multiplexing/ Demultiplexing 多路复用

![image-20211208150635209](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211208150635209.png)

![image-20211208150752436](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211208150752436.png)

<img src="C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211208151113027.png" alt="image-20211208151113027" style="zoom:50%;" />define a socket..

**UDP: User Datagram Protocol**

Lost/ Delivered out-of-order

Why UDP: doesn't require connection..

**UDP Checksum:** 

![image-20211208152731884](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211208152731884.png)

![image-20211208152754893](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211208152754893.png)

### RDT Reliable Data Transfer

rdt 1.0 perfect

RDT 2.0 with Bit Error but has a fatal flaw

![image-20211208153237965](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211208153237965.png)

What happened if ACK/ NAK corrupted? -> stop and wait

![image-20211208153641276](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211208153641276.png)

![image-20211208153838299](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211208153838299.png)

![image-20211208154056981](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211208154056981.png)

![image-20211208154203938](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211208154203938.png)

![image-20211208154338657](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211208154338657.png)

**RDT 3.0**

![image-20211208154439627](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211208154439627.png)

![image-20211208154517873](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211208154517873.png)

![image-20211208154533927](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211208154533927.png)

![image-20211208154602423](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211208154602423.png)

![image-20211208154916190](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211208154916190.png)

### TCP

![image-20211208155254450](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211208155254450.png)

![image-20211208155438723](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211208155438723.png)

TCP Sequence Number

![image-20211208155531367](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211208155531367.png)

[Transport Layer.pdf](file:///C:/Users/calvchen/Downloads/Transport Layer.pdf)

![image-20211208202706890](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211208202706890.png)

![image-20211208202910203](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211208202910203.png)

TCP Round Trip Time (RTT)

![image-20211208203111895](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211208203111895.png)

![image-20211208203211081](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211208203211081.png)

Lost

![image-20211208203700052](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211208203700052.png)

![image-20211208203954884](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211208203954884.png)

![image-20211208204112846](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211208204112846.png)
# Week #6

[Solutions1](C:\Users\calvchen\Documents/Week06_Additional_Questions_Solutions_I.pdf), [Solutions2](C:\Users\calvchen\Documents/Week06_Additional_Questions_Solutions_II.pdf)

## Process

![image-20211103103828303](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211103103828303.png)

![image-20211103104254633](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211103104254633.png)

![image-20211103104301910](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211103104301910.png)

![image-20211103104322323](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211103104322323.png)

![image-20211103104458499](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211103104458499.png)

![image-20211103104628916](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211103104628916.png)

## Process Control Block (PCB)

![image-20211103104755384](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211103104755384.png)

![image-20211103110149991](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211103110149991.png)

![image-20211103104939354](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211103104939354.png)

![image-20211103105401212](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211103105401212.png)

## Threads

![image-20211103105502518](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211103105502518.png)

![image-20211103110308241](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211103110308241.png)

![image-20211103110457848](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211103110457848.png)

![image-20211103110640361](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211103110640361.png)

![image-20211103110824810](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211103110824810.png)

![image-20211103110959918](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211103110959918.png)

![image-20211103111122267](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211103111122267.png)

![image-20211103111356660](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211103111356660.png)

![image-20211103111623412](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211103111623412.png)

![image-20211103111642823](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211103111642823.png)

![image-20211103111649268](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211103111649268.png)

![image-20211103111801087](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211103111801087.png)

![image-20211103111944055](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211103111944055.png)

![image-20211103112049787](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211103112049787.png)

### Swapping

![image-20211103132503892](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211103132503892.png)

![image-20211103132612596](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211103132612596.png)

![image-20211103132938600](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211103132938600.png)

![image-20211103133339789](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211103133339789.png)

![image-20211103133349639](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211103133349639.png)

![image-20211103133455103](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211103133455103.png)

![image-20211103133526912](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211103133526912.png)

![image-20211103133651198](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211103133651198.png)

![image-20211103133744152](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211103133744152.png)

![image-20211103133923955](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211103133923955.png)

![image-20211103134154612](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211103134154612.png)

![image-20211103134201229](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211103134201229.png)

![image-20211103134206104](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211103134206104.png)

![image-20211103134304079](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211103134304079.png)

![image-20211103134421826](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211103134421826.png)

Execution of the Opeartion System

![image-20211103134430720](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211103134430720.png)

![image-20211103134519180](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211103134519180.png)

### **Kernel**

![image-20211103134726724](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211103134726724.png)

![image-20211103134733448](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211103134733448.png)

![image-20211103134741451](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211103134741451.png)

![image-20211103135149211](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211103135149211.png)

### Context Switch

why need it?

A context switching allows a single CPU to handle multiple process requests simultaneously without the need for any additional processors. Suppose that multiple processes are stored in a Process Control Block (PCB). One process is running state to execute its task with the use of CPUs.

[Process Scheduling (1).pdf](file:///C:/Users/calvchen/Downloads/Process Scheduling (1).pdf)

### Part2 Process Scheduling

Single processor -- single process can run at a time

**CPU Scheduling** - which process to execute next

![image-20220104163653329](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20220104163653329.png)

Batch Processing: CPU Bound

Interaction sys: I/O Bound

####  CPU-I/O Burst Cycle

![image-20220104163931393](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20220104163931393.png)

Burst 执行时间

#### CPU Scheduler

Dispatcher: 1 **Switch** context, 2 switch to user mode, 3 jump to the proper loc in the user program to restart 

Diapatch Latency: time that stop one process and start another

Recall : whenever the CPU is idle, the OS mush select the next

[**user mode and kernel mode ?**](https://docs.microsoft.com/en-us/windows-hardware/drivers/gettingstarted/user-mode-and-kernel-mode)

Depending on what type of code is running on the processor.

Applications run in user mode, and core operating system components run in kernel mode.

If a kernel-mode driver crashes, the entire operating system crashes.

![image-20220104164901591](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20220104164901591.png)

### Preemptive Scheduling

[Process Scheduling.pdf](file:///C:/Users/calvchen/Downloads/Process Scheduling.pdf)![image-20220104165005833](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20220104165005833.png)

![image-20220104165455349](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20220104165455349.png)

#### FCFS

with a FIFO queue

![image-20220104170123583](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20220104170123583.png)

### Shortest-Job First (SJF) Scheduling

![image-20220104170315893](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20220104170315893.png)

Hard to determine the run time

![image-20220104170618102](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20220104170618102.png)

**Preemptive** SJF scheduling called Shortest-**Remaining**-Time-First (**SRTF**) scheduling

![image-20220104220850832](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20220104220850832.png)

#### Priority Scheduling![image-20220104170905055](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20220104170905055.png)

**Preemptive**

![image-20220104221034259](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20220104221034259.png)

#### Priority Scheduling – Problems

![image-20220104221354359](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20220104221354359.png)

#### Round-Robin (RR) Scheduling

![image-20220104221734138](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20220104221734138.png)

![image-20220104222201400](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20220104222201400.png)

![image-20220104222217250](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20220104222217250.png)

![image-20220104222328800](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20220104222328800.png)

## Advantage of Round-robin Scheduling

Here, are pros/benefits of Round-robin scheduling method:

- It doesn’t face the issues of starvation or convoy effect.
- All the jobs get a fair allocation of CPU.
- It deals with all process without any priority
- If you know the total number of processes on the run queue, then you can also assume the worst-case response time for the same process.
- This scheduling method does not depend upon burst time. That’s why it is easily implementable on the system.
- Once a process is executed for a specific set of the period, the  process is preempted, and another process executes for that given time  period.
- Allows OS to use the Context switching method to save states of preempted processes.
- It gives the best performance in terms of average response time.

## Disadvantages of Round-robin Scheduling

Here, are drawbacks/cons of using Round-robin scheduling:

- If slicing time of OS is low, the processor output will be reduced.
- This method spends more time on context switching
- Its performance heavily depends on time quantum.
- Priorities cannot be set for the processes.
- Round-robin scheduling doesn’t give special priority to more important tasks.
- Decreases comprehension
- Lower time quantum results in higher the context switching overhead in the system.
- Finding a correct time quantum is a quite difficult task in this system.

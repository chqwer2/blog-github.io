# Week 1

### Number

![image-20211015161914359](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211015161914359.png)

**How to convert?**

![image-20211015162033595](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211015162033595.png)

![image-20211015162324172](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211015162324172.png)

-92.8828127_10 -> 16bit number

![image-20220105142801829](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20220105142801829.png)

![image-20220105142916939](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20220105142916939.png)

![image-20220105143312317](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20220105143312317.png)

![image-20220105143822334](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20220105143822334.png)

![image-20220105143844517](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20220105143844517.png)

![image-20211015161413621](C:\Users\calvchen\AppData\Roaming\Typora\typora-user-images\image-20211015161413621.png)